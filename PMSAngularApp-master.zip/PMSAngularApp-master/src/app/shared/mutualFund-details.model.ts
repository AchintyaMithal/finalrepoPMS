export class MutualFundDetails{
    
    mutualFundName:string="";
   
    amount:number=0;
    
}