export class StockDetails{
    
    assetName:string="";
    assetType:string="";
    portfolioId:string="";
    
    
}