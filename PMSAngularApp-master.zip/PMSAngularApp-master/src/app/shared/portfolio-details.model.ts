import { StockDetails } from "./stock-details.model";
import { MutualFundDetails } from "./mutualFund-details.model";
export class PortfolioDetails{
    
    portFolioId:number=0;
    netWorth:number=0;
    stocklist: string="";
    mutuallist:string="";
    //amount:number=0;
    //transactionDate:string="";
    //stockId: number=0;
   // list <StockDetails> sd = new list<StockDetails>;
}